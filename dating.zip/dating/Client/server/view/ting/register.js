let username = document.getElementById('Username');
let password = document.getElementById('Password');
let email = document.getElementById('Email');
let firstname = document.getElementById('firstname');
let lastname = document.getElementById('lastname');
let age = document.getElementById('age');
let registerButton = document.getElementById('register');




function addUser(){
    const xhr = new XMLHttpRequest();
    xhr.responseType = 'json';



    let data = {
    username: username.value,
    password: password.value,
    email: username.value,
    firstname: firstname.value,
    lastname: lastname.value,
    age: age.value,

    };

    console.log(data);


    xhr.addEventListener("readystatechange", function(){
    if(this.readyState ===  4){
        const resp = this.response; // det vi får tilvage fra serveren
        alert("Useren er oprettet");
    } 
    })

    xhr.open("POST", "http://localhost:4000/users") // åbner det vi har fået
    xhr.setRequestHeader('Content-Type', "application/json"); // det der bliver sent ind, det er i json.
    let newJson = JSON.stringify(data); // vi laver data  til json
    xhr.send(newJson) // sender Json data til serveren
}

registerButton.addEventListener("click",addUser)