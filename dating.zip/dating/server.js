const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const fs = require('fs');
const { userInfo } = require('os');
const cors = require('cors');

app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


class User {
    constructor(username, password, email, firstname, lastname, age) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
    }
}

const routes = require('./routes/routes.js')(app, fs);

const server = app.listen(4000, () => {
    console.log('listening on port %s...', server.address().port);
});

app.post('http://localhost:4000/signup', (req, res)=> {
    let username = req.body.username;
    let password = req.body.password;
    let email = req.body.email;
    let firstname = req.body.firstname;
    let lastname = req.body.lastname;
    let age = req.body.age;


    let myFileJSON = fs.readFileSync('userData/testFile.json');
    let arr = JSON.parse(myFileJSON);

    let newUser = new User(username,password,email,firstname,lastname,age);

    console.log(newUser);
    arr.push(newUser);

    let toSendBackToFile = JSON.stringify(arr);
    fs.writeFileSync('userData/testFile.json', toSendBackToFile)

    res.send(JSON.stringify(['test']));

});

/*
app.post('http: //like' (req, res) => {
    let userNameee = decodedToken
    
    let fileAsArray = JSON.parse(fs.read...app.)

    let index = 0;

    for (let i=0; i<fileAsArray.length; i++) {
        if (userNameee === fileAsArray[i].username) {
            index = i;
            break;
        }
    }

    /*
    let thisUser = new User(fileAsArray[index].username, fileAsArray[index].password)

    thisUser.like(req.body.likedUser);
*/
    